﻿//------------------------------------------------------
var latitud = 41.2801939;//41.27000; 
var longitud = 1.3993976;//1.39900;
var negocio = "Rural Jord&agrave;";
var direccion = "c/Sant Antoni, 5. 43820 Rodony&agrave; - Tarragona"
var telefono = "977 62 83 05 / 629 014 231";
var web = "www.ruraljorda.cat";
var weblink = "<a href=\"http://www.ruraljorda.cat/\" target=\"_blank\">www.ruraljorda.cat</a>";
//-------------------------------------------------------
var	maptype = "G_NORMAL_MAP";
//maptype = "G_SATELLITE_TYPE";
//maptype = "G_PHYSICAL_MAP";
var zoom_inicial = 15;
var	idioma_mapa = "ca";
//-------------------------------------------------------
var map;  
var gdir;  
var geocoder = null;  
var addressMarker;  

//funcion para cargar el mapa principal cuando todavia no se ha dado ninguna direccion
		function load() {  
	     if (GBrowserIsCompatible()) {        
         map = new GMap2(document.getElementById("google_map"));  
         map.setMapType(G_HYBRID_MAP);//G_NORMAL_MAP  
         // Centramos el mapa en las coordenadas con zoom 15  
         map.setCenter(new GLatLng(latitud, longitud), zoom_inicial);  
         // Creamos el punto.  
         var point = new GLatLng(latitud, longitud);  

var marca = new GMarker(point);

		// Pintamos el punto  
         map.addOverlay(marca);//new GMarker(point));  //, iconoMarca


//mostramos la informacion del negocio
//GEvent.addListener(marca, 'click', function() {
marca.openInfoWindowHtml("<b>"+ negocio +"</b><br>"+ direccion +"<br>"+ telefono +"<br>"+ weblink);
//});
		// Controles que se van a ver en el mapa  
         map.addControl(new GLargeMapControl());  
         var mapControl = new GMapTypeControl();  
         map.addControl(mapControl);  
         // Asociamos el div 'direcciones' a las direcciones que devolveremos a Google  
         gdir = new GDirections(map, document.getElementById("direcciones"));  
         // Para recoger los errores si los hubiera  
         GEvent.addListener(gdir, "error", handleErrors);  
       }  
     }  
     // Esta función calcula la ruta con el API de Google Maps  
     function setDirections(inicio_ruta,idioma_ruta) {  
       gdir.load("from: " + inicio_ruta + " to: @" + latitud + ", " + longitud ,  
                 { "locale": idioma_ruta });  
       //Con la opción locale:es hace que la ruta la escriba en castellano.  
     }  
     // Se han producido errores  
     function handleErrors(){  
        if (gdir.getStatus().code == G_GEO_UNKNOWN_ADDRESS)  
          alert("Direccion desconocida");  
        else if (gdir.getStatus().code == G_GEO_SERVER_ERROR)  
          alert("Error de Servidor");  
        else if (gdir.getStatus().code == G_GEO_MISSING_QUERY)  
          alert("Falta la direccion inicial");  
        else if (gdir.getStatus().code == G_GEO_BAD_KEY)  
          alert("Clave de Google Maps incorrecta");  
        else if (gdir.getStatus().code == G_GEO_BAD_REQUEST)  
          alert("No se ha encontrado la direccion de llegada");  
        else alert("Error desconocido");  
     }  
     function onGDirectionsLoad(){   
     }